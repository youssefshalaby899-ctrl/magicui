ATELIER NØIR — Maison de Couture
FW25 Collection Website

HOW TO USE:
1. Unzip
2. Double-click index.html to view locally
3. To upload online: drag the entire folder to Netlify Drop (https://app.netlify.com/drop)
   or upload index.html to any hosting (Vercel, GitHub Pages, Hostinger)

FEATURES:
- Cinematic hero with GSAP parallax
- Lenis smooth scroll
- Scroll-triggered reveals
- Horizontal lookbook
- Shop with filters
- Mobile responsive + reduced-motion support

No build needed. Single file.
